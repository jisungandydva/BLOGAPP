<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row">
    <div class="col-md-12">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="card-title">Selamat Datang, <?= session('username') ?>!</h2>
                <p>Email: <?= session('user_email') ?></p>
                <p>Ini adalah halaman dashboard sederhana. 🚀</p>

                <div class="mt-3">
                    <a href="<?= site_url('users') ?>" class="btn btn-success">Kelola Users</a>
                    <a href="<?= site_url('logout') ?>" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
