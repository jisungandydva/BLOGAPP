<?= $this->include('dashboard/layouts/header'); ?>
<?= $this->include('dashboard/layouts/sidebar'); ?>

<div class="content">
    <div class="card shadow-sm p-4 bg-white rounded">
        <h3 class="fw-bold mb-4">➕ Tambah User Baru</h3>

        <form action="<?= site_url('users/store') ?>" method="post">
            
            <div class="mb-3">
                <label class="form-label fw-semibold">Username</label>
                <input type="text" name="username" class="form-control" 
                       placeholder="Masukkan username" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Email</label>
                <input type="email" name="email" class="form-control"
                       placeholder="Masukkan email" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Password</label>
                <input type="password" name="password" class="form-control"
                       placeholder="Masukkan password" required>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="<?= site_url('users') ?>" class="btn btn-secondary">Batal</a>
                <button type="submit" class="btn btn-primary" style="border-radius: 8px;">Simpan</button>
            </div>

        </form>
    </div>
</div>

<?= $this->include('dashboard/layouts/footer'); ?>

<style>
    .content {
        padding: 30px 40px;
    }

    .card {
        border-radius: 12px;
        border: none;
        max-width: 700px;
        margin: auto;
    }

    .form-label {
        margin-bottom: 6px;
        display: block;
    }

    .form-control {
        width: 100%;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        font-size: 0.95rem;
    }

    button {
        padding: 8px 20px;
        font-weight: 600;
    }
</style>
