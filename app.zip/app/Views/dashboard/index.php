<?= $this->include('dashboard/layouts/header'); ?>
<?= $this->include('dashboard/layouts/sidebar'); ?>

<?php
$userPhoto = session()->get('photo');
$photoPath = 'uploads/users/' . $userPhoto;
$defaultPhoto = 'uploads/users/default.jpg';
$photo = (!empty($userPhoto) && file_exists(FCPATH.$photoPath)) ? base_url($photoPath) : base_url($defaultPhoto);
?>

<div class="navbar-custom">
    <h6>Dashboard</h6>
    <img src="<?= $photo ?>" alt="User Photo">
</div>

<div class="content">
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card p-4 shadow-sm">
                <div class="d-flex align-items-center">
                    <i class='bx bx-news me-3'></i>
                    <div>
                        <h6 class="fw-bold">Total Posts</h6>
                        <p class="text-muted mb-0">Manage all your articles</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-4 shadow-sm">
                <div class="d-flex align-items-center">
                    <i class='bx bx-user me-3'></i>
                    <div>
                        <h6 class="fw-bold">Users</h6>
                        <p class="text-muted mb-0">Registered users</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-4 shadow-sm">
                <div class="d-flex align-items-center">
                    <i class='bx bx-stats me-3'></i>
                    <div>
                        <h6 class="fw-bold">Analytics</h6>
                        <p class="text-muted mb-0">Traffic Overview</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->include('dashboard/layouts/footer'); ?>
