<div class="sidebar">
    <h4><i class='bx bxs-dashboard'></i> Admin Panel</h4>

    <a href="/dashboard" class="active"><i class='bx bxs-home'></i> Dashboard</a>
    <a href="/posts"><i class='bx bxs-news'></i> Posts</a>
    <a href="/users"><i class='bx bxs-user'></i> Users</a>
    <a href="<?= base_url('members') ?>"><i class='bx bxs-group'></i> Members</a>

    <a href="#"><i class='bx bxs-cog'></i> Settings</a>

    <!-- FIXED LOGOUT -->
    <a href="<?= site_url('logout') ?>"><i class='bx bxs-log-out'></i> Logout</a>
</div>
