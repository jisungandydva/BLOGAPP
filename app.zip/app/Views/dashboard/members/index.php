<?= $this->include('dashboard/layouts/header'); ?>
<?= $this->include('dashboard/layouts/sidebar'); ?>

<div class="content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">👥 Daftar Members</h3>
        <a href="<?= base_url('dashboard/members/create'); ?>" class="btn btn-primary"> + Tambah Member</a>
    </div>

    <div class="card shadow-sm p-3 bg-white rounded">
        <table class="table table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th style="width: 60px;">No</th>
                    <th>Nama</th>
                    <th style="width: 120px;">Foto</th>
                    <th>Deskripsi</th>
                    <th style="width: 180px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($members) && is_array($members)): ?>
                    <?php $no = 1;
                    foreach ($members as $member): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td class="fw-semibold"><?= esc($member['nama']); ?></td>
                            <td>
                                <?php if (!empty($member['foto'])): ?>
                                    <img src="<?= base_url('uploads/members/' . $member['foto']); ?>"
                                        width="70" height="70"
                                        style="object-fit: cover; border-radius: 8px; border: 1px solid #ddd;">
                                <?php else: ?>
                                    <div class="text-muted fst-italic">(Belum ada foto)</div>
                                <?php endif; ?>
                            </td>
                            <td><?= esc($member['deskripsi']); ?></td>
                            <td>
                                <a href="<?= base_url('dashboard/members/edit/' . $member['id']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="<?= base_url('dashboard/members/delete/' . $member['id']); ?>" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus member ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            Belum ada data member 🙁
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->include('dashboard/layouts/footer'); ?>

<style>
    .content {
        padding: 20px 40px;
    }

    .card {
        border-radius: 10px;
        border: none;
    }

    .table th {
        background-color: #2563eb !important;
        color: white !important;
        font-weight: 600;
    }

    .table td {
        vertical-align: middle;
    }

    .btn {
        font-size: 0.9rem;
    }
</style>