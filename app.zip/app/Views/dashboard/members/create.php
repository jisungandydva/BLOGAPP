<?= $this->include('dashboard/layouts/header'); ?>
<?= $this->include('dashboard/layouts/sidebar'); ?>

<div class="content">
    <div class="card shadow-sm p-4 bg-white rounded">
        <h3 class="fw-bold mb-4">➕ Tambah Member Baru</h3>

        <form action="<?= base_url('dashboard/members/store'); ?>" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label fw-semibold">Nama</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama lengkap" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Deskripsi</label>
                <textarea name="deskripsi" class="form-control" rows="4" placeholder="Tulis deskripsi singkat..." required></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Foto</label>
                <input type="file" name="foto" class="form-control" accept="image/*">
                <small class="text-muted">Disarankan ukuran foto persegi (1:1)</small>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="<?= base_url('dashboard/members'); ?>" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-primary" style="border-radius: 8px;">Simpan</button>
            </div>
        </form>
    </div>
</div>

<?= $this->include('dashboard/layouts/footer'); ?>

<style>
    .content {
        padding: 30px 40px;
    }

    .card {
        border-radius: 12px;
        border: none;
        max-width: 700px;
        margin: auto;
    }

    .form-label {
        margin-bottom: 6px;
        display: block;
    }

    .form-control {
        width: 100%;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        font-size: 0.95rem;
    }

    textarea.form-control {
        resize: vertical;
    }

    button {
        padding: 8px 20px;
        font-weight: 600;
    }
</style>