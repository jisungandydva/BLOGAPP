<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ------------------- DEFAULT -------------------
$routes->get('/', 'Home::index');

// ------------------- TEST MODEL -------------------
$routes->get('/testmodel', 'TestModel::index');

// ------------------- USER MANAGEMENT -------------------
$routes->group('users', ['filter' => 'auth'], static function ($routes) {
    $routes->get('/', 'UserController::index');
    $routes->get('create', 'UserController::create');
    $routes->post('store', 'UserController::store');
    $routes->get('edit/(:num)', 'UserController::edit/$1');
    $routes->post('update/(:num)', 'UserController::update/$1');
    $routes->get('delete/(:num)', 'UserController::delete/$1');
});


// ------------------- AUTH -------------------
$routes->get('/register', 'AuthController::register');
$routes->post('/register/process', 'AuthController::processRegister');

$routes->get('/login', 'AuthController::login');
$routes->post('/login/process', 'AuthController::processLogin');
$routes->get('/logout', 'AuthController::logout');

// ------------------- DASHBOARD -------------------
$routes->get('/dashboard', 'DashboardController::index', ['filter' => 'auth']);

// ------------------- MEMBERS CRUD -------------------
$routes->group('members', ['filter' => 'auth'], static function ($routes) {
    $routes->get('/', 'MemberController::index');
    $routes->get('create', 'MemberController::create');
    $routes->post('store', 'MemberController::store');
    $routes->get('edit/(:num)', 'MemberController::edit/$1');
    $routes->post('update/(:num)', 'MemberController::update/$1');
    $routes->get('delete/(:num)', 'MemberController::delete/$1');
});
// ------------------- POSTS CRUD -------------------
$routes->group('posts', ['filter' => 'auth'], static function ($routes) {
    $routes->get('/', 'PostController::index');
    $routes->get('create', 'PostController::create');
    $routes->post('store', 'PostController::store');
    $routes->get('edit/(:num)', 'PostController::edit/$1');
    $routes->post('update/(:num)', 'PostController::update/$1');
    $routes->get('delete/(:num)', 'PostController::delete/$1');
});